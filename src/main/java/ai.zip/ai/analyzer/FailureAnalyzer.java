package ai.analyzer;

import ai.prompt.PromptBuilder;
import ai.service.AIService;

public class FailureAnalyzer {

    private final AIService aiService =
            new AIService();

    public String analyze(

            String testName,

            @org.jetbrains.annotations.UnknownNullability Throwable exception,

            String stackTrace)

            throws Exception {

        String prompt =

                PromptBuilder.buildFailurePrompt(

                        testName,

                        exception.toString(),

                        stackTrace);

        return aiService.ask(prompt);

    }

}