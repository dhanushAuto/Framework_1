package ai.analyzer;

public class AIAnalysisResult {

    private String rootCause;
    private String possibleReasons;
    private String recommendation;
    private String confidence;

}
