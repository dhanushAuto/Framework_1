package ai.client;

import ai.model.OllamaRequest;
import ai.model.OllamaResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import utilities.api.config_utils;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.core5.util.Timeout;

public class AIClient {

    public String askAI(String prompt) throws Exception {

        ObjectMapper mapper = new ObjectMapper();

        OllamaRequest request = new OllamaRequest();

        request.setModel(config_utils.getProperty("ai.model"));

        request.setPrompt(prompt);

        request.setStream(false);
        request.setThink(false);

        String json = mapper.writeValueAsString(request);

        HttpPost post = new HttpPost(config_utils.getProperty("ai.url"));


        post.setEntity(new StringEntity(json, ContentType.APPLICATION_JSON));

        RequestConfig config = RequestConfig.custom()
                .setResponseTimeout(Timeout.ofMinutes(5))
                .build();

        try (CloseableHttpClient client = HttpClients.custom()
                .setDefaultRequestConfig(config)
                .build()) {

            String body = client.execute(post, httpResponse -> {

                int statusCode = httpResponse.getCode();

                String responseBody = new String(
                        httpResponse.getEntity().getContent().readAllBytes());

                if (statusCode != 200) {
                    throw new RuntimeException(
                            "Ollama Error : " + statusCode + "\n" + responseBody);
                }

                return responseBody;
            });

            OllamaResponse aiResponse =
                    mapper.readValue(body, OllamaResponse.class);

            System.out.println("Status Code : 200");


            return aiResponse.getResponse();
        }
    }
}
