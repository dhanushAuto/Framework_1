package ai.prompt;

public class PromptBuilder {

    public static String buildFailurePrompt(
            String testName,
            String exception,
            String stackTrace) {

        StringBuilder prompt = new StringBuilder();

        prompt.append("""
You are a Senior Automation Architect.

Analyze the following failed automation test.

                Provide:
                1. Root Cause
                
                2. Suggested Fix

----------------------------------------""");

        prompt.append("Test Name : ")
                .append(testName)
                .append("\n\n");

        prompt.append("Exception : ")
                .append(exception)
                .append("\n\n");

        prompt.append("Stack Trace :\n")
                .append(stackTrace);

        return prompt.toString();
    }

}